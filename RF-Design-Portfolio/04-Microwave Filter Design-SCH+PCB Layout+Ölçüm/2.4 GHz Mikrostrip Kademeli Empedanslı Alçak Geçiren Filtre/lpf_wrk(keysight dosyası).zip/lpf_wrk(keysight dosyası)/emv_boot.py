# -*- coding: utf-8 -*-

import empro.toolkit.adv as adv

def main():
	path=r"C:/Users/ali/lpf_wrk"
	lib=r"lpf_lib"
	subst=r"lpf_lib/Rogers RO4003C.subst"
	substlib=r"lpf_lib"
	substname=r"Rogers RO4003C"
	cell=r"lpfsch"
	view=r"layout"
	libS3D=r"simulation/lpf_lib/lpfsch/_3%D%Viewer/proj_libS3D.xml"
	varDictionary={}
	exprDictionary={}
	adv.loadDesign(path=path, lib=lib, subst=subst, substlib=substlib, substname=substname, cell=cell, view=view, libS3D=libS3D, var_dict=varDictionary, expr_dict=exprDictionary)
